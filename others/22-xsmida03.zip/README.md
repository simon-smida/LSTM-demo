# SFC-project
Long Short-Term Memory (LSTM) demonstration


## Application demonstration 
- entering input sequence: `0,1,0,1`
- started training
- next symbol prediction
  
<p align="center">
  <img src="img/demo-app.gif"/>
</p>

## Training visualization
![](img/demo-visual.gif)
